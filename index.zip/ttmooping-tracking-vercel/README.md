# ttmooping 宅配單號查詢

顧客可使用訂購時填寫的手機號碼查詢黑貓冷凍宅配單號。

## Deploy to Vercel

1. Upload this project to a GitHub repository.
2. In Vercel, select **Add New → Project** and import the repository.
3. Leave **Framework Preset** as `Other`.
4. Vercel will read `vercel.json` and publish the `dist` folder automatically.

No environment variables or build command are required.
